@extends('layouts.app')

@section('content')
<div class="container mx-auto px-4">
    <h1 class="text-2xl font-bold mb-4">Daftar Barang Masuk</h1>

    <div class="bg-white shadow-md rounded my-6">
        <table class="min-w-full table-auto">
            <thead>
                <tr class="bg-gray-200 text-gray-600 uppercase text-sm leading-normal">
                    <th class="py-3 px-6 text-left">Tanggal</th>
                    <th class="py-3 px-6 text-left">Nama Barang</th>
                    <th class="py-3 px-6 text-center">Jumlah</th>
                    <th class="py-3 px-6 text-right">User</th>
                    <th class="py-3 px-6 text-left">Catatan</th>
                    <th class="py-3 px-6 text-center">Aksi</th>
                </tr>
            </thead>
            <tbody class="text-gray-600 text-sm font-light">
                @foreach($incomingGoods as $incoming)
                <tr class="border-b border-gray-200 hover:bg-gray-100">
                    <td class="py-3 px-6 text-left">
                        {{ $incoming->date->format('d/m/Y') }}
                    </td>
                    <td class="py-3 px-6 text-left">
                        {{ $incoming->item->name }}
                    </td>
                    <td class="py-3 px-6 text-center">
                        {{ $incoming->quantity }}
                    </td>
                    <td class="py-3 px-6 text-right">
                        {{ $incoming->user->name }}
                    </td>
                    <td class="py-3 px-6 text-left">
                        {{ $incoming->notes }}
                    </td>
                    <td class="py-3 px-6 text-center">
                        <a href="{{ route('incoming_goods.edit', $incoming->id) }}" class="text-blue-600 hover:text-blue-900">Edit</a>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        <a href="{{ route('incoming_goods.create') }}" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
            Tambah Barang Masuk
        </a>
    </div>
</div>
@endsection
