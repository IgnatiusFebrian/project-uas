<?php $__env->startSection('content'); ?>
    <div class="container py-4">
        <h1 class="mb-4">Dashboard</h1>

        <div class="row g-4 mb-4">
            <div class="col-md-4">
                <div class="card text-center shadow-sm">
                    <div class="card-body">
                        <h5 class="card-title">Net Sales</h5>
                        <p class="display-6"><?php echo e(number_format($netSales, 2)); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card text-center shadow-sm">
                    <div class="card-body">
                        <h5 class="card-title">Total Profit</h5>
                        <p class="display-6"><?php echo e(number_format($totalProfit, 2)); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card text-center shadow-sm">
                    <div class="card-body">
                        <h5 class="card-title">Total Transactions</h5>
                        <p class="display-6"><?php echo e($totalTransactions); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mt-4">
                <div class="card text-center shadow-sm">
                    <div class="card-body">
                        <h5 class="card-title">Items Sold</h5>
                        <p class="display-6"><?php echo e($itemsSold); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mt-4">
                <div class="card text-center shadow-sm">
                    <div class="card-body">
                        <h5 class="card-title">Stock Info</h5>
                        <p class="display-6"><?php echo e($totalStock); ?></p>
                    </div>
                </div>
            </div>
        </div>

    <div class="card mb-4 shadow-sm">
        <div class="card-body">
            <h5 class="card-title mb-3">Sales Over Time</h5>
            <canvas id="salesOverTimeChart" height="100"></canvas>
        </div>
    </div>

    <div class="card mb-4 shadow-sm">
        <div class="card-body">
            <h5 class="card-title mb-3">Product Sales</h5>
            <canvas id="productSalesChart" height="100"></canvas>
        </div>
    </div>

    <div class="card shadow-sm">
        <div class="card-body">
            <h5 class="card-title mb-3">Recent Transactions</h5>
            <div class="table-responsive">
                <table class="table table-bordered table-hover mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>ID</th>
                            <th>Type</th>
                            <th>Date</th>
                            <th>Total Price</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $recentTransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($transaction['id']); ?></td>
                            <td><?php echo e(ucfirst($transaction['type'])); ?></td>
                            <td><?php echo e($transaction['date']); ?></td>
                            <td>
                                <?php if(isset($transaction['total_price'])): ?>
                                    <?php echo e(number_format($transaction['total_price'], 2)); ?>

                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        const salesOverTimeCtx = document.getElementById('salesOverTimeChart').getContext('2d');
        const salesOverTimeChart = new Chart(salesOverTimeCtx, {
            type: 'line',
            data: {
                labels: <?php echo json_encode($salesOverTimeLabels); ?>,
                datasets: [{
                    label: 'Sales Over Time',
                    data: <?php echo json_encode($salesOverTimeData); ?>,
                    borderColor: 'rgba(54, 162, 235, 1)',
                    backgroundColor: 'rgba(54, 162, 235, 0.2)',
                    fill: true,
                    tension: 0.1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    x: { display: true },
                    y: { display: true, beginAtZero: true }
                }
            }
        });

        const productSalesCtx = document.getElementById('productSalesChart').getContext('2d');
        const productSalesChart = new Chart(productSalesCtx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($productSalesLabels); ?>,
                datasets: [{
                    label: 'Product Sales',
                    data: <?php echo json_encode($productSalesData); ?>,
                    backgroundColor: 'rgba(255, 159, 64, 0.7)'
                }]
            },
            options: {
                responsive: true,
                scales: {
                    x: { display: true },
                    y: { display: true, beginAtZero: true }
                }
            }
        });
    </script>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ignas\OneDrive\Dokumen\Backend\UAS\distributor\resources\views/dashboard.blade.php ENDPATH**/ ?>