<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4">
    <h1 class="text-2xl font-bold mb-4">Outgoing Goods Transactions</h1>

    <?php if(session('success')): ?>
        <div class="mb-4 p-4 bg-green-100 text-green-700 rounded">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <a href="<?php echo e(route('outgoing_goods.create')); ?>" class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mb-4 inline-block">
        Create New Outgoing Goods Transaction
    </a>

    <table class="min-w-full bg-white border border-gray-200 rounded">
        <thead>
            <tr>
                <th class="py-2 px-4 border-b">Date</th>
                <th class="py-2 px-4 border-b">Item Name</th>
                <th class="py-2 px-4 border-b">Quantity</th>
                <th class="py-2 px-4 border-b">Price per Unit</th>
                <th class="py-2 px-4 border-b">Total Price</th>
                <th class="py-2 px-4 border-b">User</th>
                <th class="py-2 px-4 border-b">Notes</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $outgoingGoods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $outgoing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="py-2 px-4 border-b"><?php echo e($outgoing->date); ?></td>
                    <td class="py-2 px-4 border-b"><?php echo e($outgoing->item->name); ?></td>
                    <td class="py-2 px-4 border-b"><?php echo e($outgoing->quantity); ?></td>
                    <td class="py-2 px-4 border-b"><?php echo e(number_format($outgoing->price, 2)); ?></td>
                    <td class="py-2 px-4 border-b"><?php echo e(number_format($outgoing->quantity * $outgoing->price, 2)); ?></td>
                    <td class="py-2 px-4 border-b"><?php echo e($outgoing->user->name); ?></td>
                    <td class="py-2 px-4 border-b"><?php echo e($outgoing->notes); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="py-4 px-4 text-center text-gray-500">No outgoing goods transactions found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ignas\OneDrive\Dokumen\Backend\UAS\distributor\resources\views/outgoing_goods/index.blade.php ENDPATH**/ ?>