<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4">
    <h1 class="text-2xl font-bold mb-4">Daftar Barang Masuk</h1>

    <div class="bg-white shadow-md rounded my-6">
        <table class="table table-striped table-hover">
            <thead class="table-dark">
                <tr>
                    <th>Tanggal</th>
                    <th>Nama Barang</th>
                    <th class="text-center">Jumlah</th>
                    <th>User</th>
                    <th>Catatan</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $incomingGoods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $incoming): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($incoming->date->format('d/m/Y')); ?></td>
                    <td><?php echo e($incoming->item->name); ?></td>
                    <td class="text-center"><?php echo e($incoming->quantity); ?></td>
                    <td><?php echo e($incoming->user->name); ?></td>
                    <td><?php echo e($incoming->notes); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        <a href="<?php echo e(route('incoming_goods.create')); ?>" class="btn btn-primary">
            Tambah Barang Masuk
        </a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ignas\OneDrive\Dokumen\Backend\UAS\distributor\resources\views/incoming_goods/index.blade.php ENDPATH**/ ?>