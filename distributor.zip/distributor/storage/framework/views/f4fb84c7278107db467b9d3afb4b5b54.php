<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <h1 class="mb-4">Daftar Barang</h1>

    <form method="GET" action="<?php echo e(route('items.index')); ?>" class="mb-4 row g-3 align-items-center">
        <div class="col-auto">
            <label for="start_date" class="col-form-label">Tanggal Mulai:</label>
        </div>
        <div class="col-auto">
            <input type="date" id="start_date" name="start_date" value="<?php echo e(request('start_date')); ?>" class="form-control">
        </div>
        <div class="col-auto">
            <label for="end_date" class="col-form-label">Tanggal Akhir:</label>
        </div>
        <div class="col-auto">
            <input type="date" id="end_date" name="end_date" value="<?php echo e(request('end_date')); ?>" class="form-control">
        </div>
        <div class="col-auto">
            <button type="submit" class="btn btn-primary">Filter</button>
        </div>
    </form>

    <a href="<?php echo e(route('items.create')); ?>" class="btn btn-primary mb-4">+ Tambah Barang</a>

    <?php if(session('success')): ?>
        <div class="alert alert-success mb-4">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <table class="table table-bordered table-hover">
        <thead class="table-light">
            <tr>
                <th>Nama</th>
                <th>Stok</th>
                <th>Barang Keluar</th>
                <th>Harga</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="border-b border-gray-200 hover:bg-gray-100">
                <td><?php echo e($item->name); ?></td>
                <td><?php echo e($item->stock); ?></td>
                <td><?php echo e($item->total_outgoing); ?></td>
                <td><?php echo e($item->price); ?></td>
                <td>
                    <a href="<?php echo e(route('items.edit', $item->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                    <a href="<?php echo e(route('outgoing_goods.create', ['item_id' => $item->id])); ?>" class="btn btn-danger btn-sm ms-2">Barang Keluar</a>
                    <form action="<?php echo e(route('items.destroy', $item->id)); ?>" method="POST" class="d-inline ms-2">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Hapus barang ini?')">Hapus</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ignas\OneDrive\Dokumen\Backend\UAS\distributor\resources\views/items/index.blade.php ENDPATH**/ ?>